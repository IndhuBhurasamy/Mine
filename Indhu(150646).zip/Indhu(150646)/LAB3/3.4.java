
import java.util.Arrays;
import java.util.Scanner;
public class ProductNames {
	public static void main(String[] args) {
		System.out.println("Enter the number of strings you want to sort");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		String str[]=new String[n];
		System.out.println("Enter any strings");
		Scanner sc=new Scanner(System.in);
		for(int index1=0;index1<str.length;index1++)
		{
		str[index1]=sc.nextLine();
		}
		
		Arrays.sort(str);
		
		System.out.println("Strings after sorting");
		for(int index2=0;index2<str.length;index2++)
		{
			System.err.println(str[index2]);
		}
	}
}

Output:

Enter the number of strings you want to sort
3
Enter any strings
Indhu
Gnana
Deiva
Strings after sorting
Deiva
Gnana
Indhu