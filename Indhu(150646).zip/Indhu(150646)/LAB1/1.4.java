package lab1;

public class Exercise4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Personal Details");
		System.out.println("________________");
		System.out.println("First Name: Indhu");
		System.out.println("Last Name: Bhurasamy");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");
	}

}

Output:
Age: 20
Weight: 85.55
