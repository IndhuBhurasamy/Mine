public class personclass {
	String Firstname;
	String Lastname;
	char Gender;
	
	public Personclass(String Fname, String Lname,char G)
	{
		Firstname=Fname;
		 Lastname=Lname;
		 Gender=G;
		
		displayDetails();
		}
	
	public void getDetails(String  fname, String lname, char gen)
	{
		Firstname=fname;
				 Lastname=lname;
				 Gender=gen;
	}
	
public void displayDetails()
{
	System.out.println("First Name : "+ Firstname);
	System.out.println("Last Name : "+ Lastname);
	System.out.println("Gender : "+ Gender);
	System.out.println("____________________________");
	}
public static void main(String args[])
{
	 System.out.println("Person Details");
		System.out.println("______________");
	Personclass person= new Personclass("Indhu", "Bhurasamy", 'F');
	Personclass person1= new Personclass(" Raju", "Anandh", 'M');
	Personclass person2= new Personclass("Swathi", "Bhurasamy", 'F');
	Personclass person3= new Personclass("Shalini", "Bhurasamy", 'M');
}
}

Output
Person Details
______________
First Name : Indhu
Last Name : Bhurasamy
Gender : F
____________________________
First Name :  Raju
Last Name : Anandh
Gender : M
____________________________
First Name : Swathi
Last Name : Bhurasamy
Gender : F
____________________________
First Name : Shalini
Last Name : Bhurasamy
Gender : M
____________________________
