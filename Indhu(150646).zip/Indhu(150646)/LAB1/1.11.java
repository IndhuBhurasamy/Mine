
import java.time.*;
public class Exercise19 {
   public static void main(String[] args)
 {
	     LocalDate today = LocalDate.now();    
	     LocalDate userday = LocalDate.of(2017, Month.JUNE, 29); 
	     Period diff = Period.between(userday, today); 
	     System.out.println("\nDuration between "+ userday +" and "+ today +": " 
	     + diff.getYears() +" Year(s) and "+ diff.getMonths() +" Month(s) and " + diff.getDays() +" Days(s)\n");
	    }
}

Output: Duration between 2017-06-29 and 2018-07-09: 1 Year(s) and 0 Month(s) and 10 Days(s)