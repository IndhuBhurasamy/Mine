import java.time.*;
public class ZoneTime {
   public static void main(String[] args)
    {
    ZoneId.SHORT_IDS.keySet().
    stream().forEach( 
    zoneKey ->System.out.println(" "+ ZoneId.of( ZoneId.SHORT_IDS.get( zoneKey ) ) +": "+ LocalDateTime.now(ZoneId.of(ZoneId.SHORT_IDS.get( zoneKey ) ) ) ) );
    }
}


Output:
 Asia/Shanghai: 2018-07-09T19:43:45.758
 Africa/Cairo: 2018-07-09T14:43:45.758
 America/St_Johns: 2018-07-09T09:13:45.758
 America/Puerto_Rico: 2018-07-09T07:43:45.758
 America/Phoenix: 2018-07-09T04:43:45.758
 Asia/Karachi: 2018-07-09T16:43:45.758
 America/Anchorage: 2018-07-09T03:43:45.758
 Asia/Dhaka: 2018-07-09T17:43:45.758
 America/Chicago: 2018-07-09T06:43:45.758
 -05:00: 2018-07-09T06:43:45.758
 -10:00: 2018-07-09T01:43:45.758
 Asia/Tokyo: 2018-07-09T20:43:45.758
 Asia/Kolkata: 2018-07-09T17:13:45.758
 America/Argentina/Buenos_Aires: 2018-07-09T08:43:45.758
 Pacific/Auckland: 2018-07-09T23:43:45.758
 -07:00: 2018-07-09T04:43:45.758
 Australia/Sydney: 2018-07-09T21:43:45.758
 America/Sao_Paulo: 2018-07-09T08:43:45.758
 America/Los_Angeles: 2018-07-09T04:43:45.758
 Australia/Darwin: 2018-07-09T21:13:45.758
 Pacific/Guadalcanal: 2018-07-09T22:43:45.758
 Asia/Ho_Chi_Minh: 2018-07-09T18:43:45.758
 Africa/Harare: 2018-07-09T13:43:45.758
 Europe/Paris: 2018-07-09T13:43:45.758
 Africa/Addis_Ababa: 2018-07-09T14:43:45.758
 America/Indiana/Indianapolis: 2018-07-09T07:43:45.758
 Pacific/Apia: 2018-07-10T00:43:45.758
 Asia/Yerevan: 2018-07-09T15:43:45.768