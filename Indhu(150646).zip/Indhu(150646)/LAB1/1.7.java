public class MobilenumberAddition {
	String Firstname;
	String Lastname;
	char Gender;
	String number;
	
	public MobilenumberAddition(String Fname, String Lname,char G,String num)
	{
		Firstname=Fname;
		 Lastname=Lname;
		 Gender=G;
		 number=num;
		
		displayDetails();
		}
	
	public void getDetails(String  fname, String lname, char gen,String no)
	{
		Firstname=fname;
				 Lastname=lname;
				 Gender=gen;
				 number=no;
	}
	
public void displayDetails()
{
	System.out.println("First Name : "+ Firstname);
	System.out.println("Last Name : "+ Lastname);
	System.out.println("Gender : "+ Gender);
	System.out.println("Mobile Number : "+number);
	System.out.println("____________________________");
	}
public static void main(String args[])
{
	 System.out.println("Person Details");
		System.out.println("______________");
		MobilenumberAddition person= new MobilenumberAddition("Lalitha", "Chatti", 'F',"1231231234");
		MobilenumberAddition person1= new MobilenumberAddition("Paidi Raju", "Chatti", 'M',"1231231234");
		MobilenumberAddition person2= new MobilenumberAddition("Indhu", "Chatti", 'F',"1231231234");
		MobilenumberAddition person3= new MobilenumberAddition("Shailaja", "Chatti", 'M',"1564564567");
}
}


Output:

Person Details
______________
First Name : Lalitha
Last Name : Chatti
Gender : F
Mobile Number : 1231231234
____________________________
First Name : Paidi Raju
Last Name : Chatti
Gender : M
Mobile Number : 1231231234
____________________________
First Name : Indhu
Last Name : Chatti
Gender : F
Mobile Number : 1231231234
____________________________
First Name : Shailaja
Last Name : Chatti
Gender : M
Mobile Number : 1564564567