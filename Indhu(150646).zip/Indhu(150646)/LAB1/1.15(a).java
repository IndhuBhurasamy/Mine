import java.time.*;
import java.util.*;

public class AgeCal{  
   public static void main(String[] args)
    {
        // date of birth
        LocalDate pdate = LocalDate.of(1997, 02, 03);
        // current date
        LocalDate now = LocalDate.now();
        // difference between current date and date of birth
        Period diff = Period.between(pdate, now);
 
     System.out.printf("\nI am  %d years, %d months and %d days old.\n\n", 
                    diff.getYears(), diff.getMonths(), diff.getDays());
   }
}

Output: I am  21 years, 5 months and 6 days old.