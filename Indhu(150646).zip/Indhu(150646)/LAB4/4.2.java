import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;


public class ReadNumbers {
public static void main(String[] args) throws IOException {
	FileReader fr=new FileReader("D:/Shivani.G/Samples/numbers.txt");
	Scanner sc=new Scanner(fr);		
		StringTokenizer str=new StringTokenizer(sc.nextLine(),",");
		   while (str.hasMoreTokens())
		   {
               String next = str.nextToken();            
            	   if(Integer.parseInt(next)%2==0)
            	   System.out.println(next);
             
            	  
           }
	}
}

Output:

2
4
6
8
10