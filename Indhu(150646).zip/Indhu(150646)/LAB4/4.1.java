import java.util.*;
import java.io.*;
 
public class ReverseString
{
    public static void main (String [] args)throws IOException
    {
        FileReader fr = new FileReader("D:/Shivani.G/Samples/input.txt");
        FileWriter fw = new FileWriter("D:/Shivani.G/Samples/reverse_output.txt");
        BufferedReader br = new BufferedReader(fr);
         
        String data;
         
       while ((data = br.readLine()) != null) {
        
        StringTokenizer tokens = new StringTokenizer(data, "\r\n");
        while (tokens.hasMoreTokens()){
                        String next = tokens.nextToken();
                        for (int index = next.length() - 1; index>=0; index--) {
                        char c = next.charAt(index);
                       fw.write(c);                
                        }
                        fw.write(" ");
                        fw.write("\r\n");
                       

            }}
         fr.close();
         fw.close();
        
       
       
                
    }
}


Output:

Input File:
Before the start of my second year of PGDBM, I got an opportunity to have a corporate exposure at ICICI regional bank.
 In addition to this exposure, it also allowed to implement some of our course learning to real business world situations. 
My internship with ICICI regional bank started on 28th June and extended till 9th august. 
ICICI Bank is India's second-largest bank with total assets of Rs. 3,634.00 billion (US$ 81 billion) at March 31, 2010.
 The Bank has a diverse network of 2,016 branches and about 5,219 ATMs in India and presence in 18 countries. 
They offer a wide range of banking products & financial services to 
corporate and retail customers through a variety of delivery channels (www.icicibank.com).




Output File:
.knab lanoiger ICICI ta erusopxe etaroproc a evah ot ytinutroppo na tog I ,MBDGP fo raey dnoces ym fo trats eht erofeB 
 .snoitautis dlrow ssenisub laer ot gninrael esruoc ruo fo emos tnemelpmi ot dewolla osla ti ,erusopxe siht ot noitidda nI  
 .tsugua ht9 llit dednetxe dna enuJ ht82 no detrats knab lanoiger ICICI htiw pihsnretni yM 
.0102 ,13 hcraM ta )noillib 18 $SU( noillib 00.436,3 .sR fo stessa latot htiw knab tsegral-dnoces s'aidnI si knaB ICICI 
 .seirtnuoc 81 ni ecneserp dna aidnI ni sMTA 912,5 tuoba dna sehcnarb 610,2 fo krowten esrevid a sah knaB ehT  
 ot secivres laicnanif & stcudorp gniknab fo egnar ediw a reffo yehT 
.)moc.knabicici.www( slennahc yreviled fo yteirav a hguorht sremotsuc liater dna etaroproc 
