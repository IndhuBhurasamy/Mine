package com.cg.eis.service;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import com.cg.eis.bean.*;

public class Service implements EmployeeService{
	int choice=1,i=0;
	Employee e;
	ResultSet rs;
	Statement st;
	PreparedStatement pst,pst1;
	Connection conn;
	public void getEmployeeDetails() throws SQLException{

		System.out.println("Enter count of employees to provide the details");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		Driver d=new oracle.jdbc.driver.OracleDriver();
		DriverManager.registerDriver(d);
		conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg310","training310");
		st=conn.createStatement();
		rs=st.executeQuery("select table_name from user_tables");
		while(rs.next())
		{
			if(rs.getString("table_name").equals("EMPLOYEE"))
				
				st.execute("drop table employee");
			
				
		}
	st.execute("create table employee(id number,name varchar2(50),salary number,designation varchar2(50),insurationscheme varchar2(50))");

		
		while(choice!=0 && i<n)
		{
			e=new Employee(0, null, 0, null, null);
			//
		System.out.println("Please enter your employee id");
		Scanner s1=new Scanner(System.in);
		e.setId(s1.nextInt());
		
		Scanner s2=new Scanner(System.in);
		System.out.println("Please enter your name");
		e.setName(s2.nextLine());
		Scanner s3=new Scanner(System.in);
		System.out.println("Enter the salary");
		e.setSalary(s3.nextInt());
		Scanner s4=new Scanner(System.in);
		System.out.println("Enter your designation as mentioned below\n"+
						    "Clerk\nSystem Associate\nProgrammer\nManager");
		e.setDesignation(s4.nextLine());
		Scanner s5=new Scanner(System.in);
		System.out.println("Enter your Insurance Scheme as mentioned below\n"+"A\nB\nC\nNo Scheme");
	    e.setInsurationScheme(s5.nextLine());
		System.out.println("Press 1 to continue filling details or press 0 to exit");
		Scanner s6=new Scanner(System.in);
		choice=s6.nextInt();

		addEmployee(e);
		++i;
		}

	if(choice==0){
System.out.println("\nAdding details to the database is completed");
	}
	}

	

	public void addEmployee(Employee e){
	
		try {
		
			
			pst=conn.prepareStatement("insert into employee values (?,?,?,?,?)");
			pst.setInt(1,e.getId());
			pst.setString(2, e.getName());
			pst.setInt(3,e.getSalary());
			pst.setString(4, e.getDesignation());
			pst.setString(5,e.getInsurationScheme());
			pst.executeUpdate();
			
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
	}
	public void searchInsurance() throws SQLException
	{
		ResultSet r=st.executeQuery("select * from employee");
	
		System.out.println("\nEnter Insurance scheme to get the details of the employee");
		
		Scanner a=new Scanner(System.in);
		String search=a.nextLine();
	
		while(r.next())
		{
	
			if(r.getString("insurationscheme").equals(search))
			{ 
				
				System.out.println("\nEmployee Id: "+r.getInt(1)+"\nEmployee Name: "+r.getString(2)+"\nSalary: "+r.getInt(3)+"\nDesignation: "+r.getString(4));
		}
			}
		}
	
	
	public void deletedetails(int id) throws SQLException{
	
		ResultSet r=st.executeQuery("select * from employee");
	
		while(r.next())
		{
			
				if(r.getInt(1)==id){
				pst1=conn.prepareStatement("delete from employee where id=?");
				pst1.setInt(1, id);
				pst1.executeUpdate();}
					
				
				
			}
		System.out.println("\nDeleted data");}
	
}
_ _ _ _ _ _
package com.cg.eis.pl;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.eis.bean.*;
import com.cg.eis.service.Service;

public class EmployeeDetails {
	public static void main(String[] args) throws SQLException {
		int c=-1;
		Service s=new Service();
		do{
		System.out.println("Select any one of the choice:\n1.Add Employee details\n2.Search details based on Insuration scheme\n3.Delete employee details\n0.Exit\n");
		Scanner sc=new Scanner(System.in);
		c=sc.nextInt();
		if(c==1)
		s.getEmployeeDetails();
		else if(c==2)
			s.searchInsurance();
		else if(c==3)
		{	System.err.println("Please enter employee id to delete the details");
			Scanner s1=new Scanner(System.in);
			int id=s1.nextInt();
			s.deletedetails(id);
		}
		else if(c==0)
			System.exit(0);
		}while(c!=0);
	
		
	
		
	}

}

Output:


Select any one of the choice:
1.Add Employee details
2.Search details based on Insuration scheme
3.Delete employee details
0.Exit
0

