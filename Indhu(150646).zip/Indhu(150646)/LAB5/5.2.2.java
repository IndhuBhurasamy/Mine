class Date
{
int intDay, intMonth, intYear;
// Constructor
Date(int intDay, int intMonth, int intYear) {
this.intDay = intDay;
this.intMonth = intMonth;
this.intYear = intYear;
}
// setter and getter methods
void setDay(int intDay)
{
this.intDay = intDay;
}
int getDay( )
{
return this.intDay;
}
void setMonth(int intMonth)
{
this.intMonth = intMonth;
}
int getMonth( )
{
return this.intMonth;
}
void setYear(int intYear)
{
this.intYear=intYear;
}
int getYear( )
{return this.intYear;
}
public String toString() //converts date obj to string.
{
return "Date is "+intDay+"/"+intMonth+"/"+intYear;
}
} // Date class

_ _ _ _  _ _ _ _

import static org.junit.Assert.*;

import org.junit.Test;


public class DateTest {

	@Test
	public void test() {
		Date d=new Date(0,0,0);
		d.setDay(20);
		d.setMonth(3);
		d.setYear(2018);
		assertEquals(20, d.getDay());
		assertEquals(3, d.getMonth());
		assertEquals(2018, d.getYear());
		
		
	}

}