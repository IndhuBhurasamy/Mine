package com.capgemini.hbms.service;

import java.util.ArrayList;
import java.util.Date;

import com.capgemini.hbms.bean.HBMSBookingBean;
import com.capgemini.hbms.bean.HBMSGuestBean;
import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHBMSService {

	boolean isValidLoginDetails(String username, String password) throws HBMSException;

	boolean registerUser(HBMSUserBean userBean) throws HBMSException;

	ArrayList<HBMSHotelBean> getHotelList() throws HBMSException;

	ArrayList<HBMSRoomBean> getRoomList(String id) throws HBMSException;

	String getUserId(String username, String password) throws HBMSException;

	float getRoomAmount(String roomId) throws HBMSException;

	String addBookingDetails(HBMSBookingBean booking) throws HBMSException;

	HBMSBookingBean getBookingDetails(String bookingId) throws HBMSException;

	String addHotelDetails(HBMSHotelBean bean) throws HBMSException;

	boolean isValidHotelId(String hotelID) throws HBMSException;

	ArrayList<HBMSBookingBean> getBookingsOfHotel(String hotelID) throws HBMSException;

	boolean deleteHotel(String hotelID) throws HBMSException;

	boolean isValidRoomId(String roomID) throws HBMSException;

	boolean deleteRoom(String roomID) throws HBMSException;

	ArrayList<HBMSGuestBean> getGuestListOfHotel(String hotelID) throws HBMSException;

	ArrayList<HBMSBookingBean> getBookingsOfSpecifiedDate(Date date1) throws HBMSException;

	void checkAvaialbilityStatus() throws HBMSException;

	void changeRoomStatus(String roomid) throws HBMSException;

	boolean isValidUserName(String userName) throws HBMSException;

	String addRoomDetails(HBMSRoomBean bean) throws HBMSException;

	void updateRoomType(HBMSRoomBean roomBean) throws HBMSException;

	void updateRoomRent(HBMSRoomBean roomBean) throws HBMSException;

	void modifyHotelRating(String hotelId, String rating) throws HBMSException;

	void modifyHotelAvgRate(String hoteliD, float avgrate) throws HBMSException;

	void modifyHotelDescription(String hoteliD, String desc) throws HBMSException;

	ArrayList<HBMSBookingBean> getBookingList(String userId) throws HBMSException;

	void deleteBooking(String bookingId) throws HBMSException;

	String getUserRole(String username, String password) throws HBMSException;

	ArrayList<HBMSBookingBean> getTotalBookingList(String userId) throws HBMSException;

}
