package com.cg.librarymgmt.junit;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Test;

public class CollectionHelperTest1 {

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented"); // TODO
	}

}
